# AFS Controller (Ubuntu)

The AFS Controller software. It runs on
the mini-PC as a background service, drives the ISOIL VEGA T2 meter through a
USB-RS485 adapter, and serves the AFS mobile apps over WiFi.

Behaviour follows AFS 5.0.3; see the AFS 5.0.3 analysis and the build
plan documents for the full specification and the phase-by-phase plan.

Status: **Phase 2** (customer API, discovery, records). The service finds the
RS-485 adapter, runs the transaction engine (boot re-attach to an open
delivery, 2 Hz session poller with AFS 5.0.3's stop rules), stores every
delivery as a 4 KB record in AFS 5.0.3's sector layout, serves the customer
API on TCP 5482 and answers the apps' discovery on UDP 5480, and shows the
meter state in `systemctl status`. WiFi setup and the device API follow in
Phase 4.

## Layout

```
cmd/afs-controller/   the service
cmd/afsctl/           technician tool on the box
cmd/vegasim/          simulated VEGA T2 meter (bench and tests; not installed)
cmd/afs-soak/         long soak of engine + serial + protocol against the simulator
cmd/afs-mock/         device API mock server for the Android app team (not installed)
internal/serial/      raw serial port, USB-RS485 auto-detection, port choice
internal/vega/        VEGA T2 frames, checksum, exchange, status/serial/ack decoders
internal/bus/         RS-485 arbiter: poll path, FIFO user path, 100 ms gap, reopen
internal/engine/      transaction engine (AFS 5.0.3 task_vega_poll) and diagnostics
internal/record/      4 KB transaction record, byte-identical to AFS 5.0.3
internal/store/       record files on disk, power-cut recovery, numbering 1..4095
internal/api/         customer API (5482): /start /stop /abort /transaction /api/info /api/diag
internal/discovery/   UDP discovery (5480)
internal/clock/       clock set from the operator's phone at /start
internal/auth/        device API login: PBKDF2 key, challenge/proof, tokens, lockout
internal/device/      device API v1 (5484) handlers, backend interface, in-memory mock
internal/vegasim/     simulator built on frames recorded from a real meter
internal/config/      /etc/afs/config.json with safe fallbacks
internal/bootinfo/    boot counter and reset reason
internal/sdnotify/    systemd ready / watchdog notifications
internal/fsutil/      power-cut-safe file writes
testdata/frames/      real meter frames extracted from docs/maintrans.txt and the serial log
tools/                fixture extractor
packaging/            systemd unit, udev rule, install scripts, .deb builder
```

No third-party Go modules: everything is the Go standard library.

## Build (any Linux with Go 1.24+)

```
make check      # gofmt, go vet, all tests with the race detector
make deb        # dist/afs-controller_<version>_amd64.deb and its .sha256
make sim        # simulated meter on a virtual serial port (prints its path)
```

The binaries are static (`CGO_ENABLED=0`), so the same `.deb` installs on
Ubuntu 22.04 and 24.04.

## Install on the box

```
sha256sum -c afs-controller_0.4.1_amd64.deb.sha256
sudo apt install ./afs-controller_0.4.1_amd64.deb
systemctl status afs-controller
journalctl -u afs-controller -f
```

Files: `/usr/bin/afs-controller`, `/usr/bin/afsctl`, `/etc/afs/config.json`
(kept on upgrade), data in `/var/lib/afs` (never deleted by the package).
Rollback: install the previous `.deb`.

## Technician tool

```
afsctl version
afsctl ports                       # USB serial adapters, USB ID and chip
sudo systemctl stop afs-controller # the service holds the port
afsctl probe                       # auto: find the adapter the meter answers on
afsctl probe /dev/ttyUSB0          # or test one port
sudo systemctl start afs-controller
sudo afsctl status | diag | last   # what the running service reports
sudo afsctl records 20             # newest records on disk
afsctl wifi                        # NetworkManager view
sudo afsctl label                  # the label password
sudo afsctl reset-password         # forgotten technician password
```

## Customer API and discovery

Same contract as AFS 5.0.3: every body, status code, field format and
fallback. `POST /start`, `/stop`, `/abort`, `/transaction` need
`{"challenge":C,"signature":MD5(C+"flow_meter_1")}`; `GET /api/info` and
`GET /api/diag` need nothing. Discovery answers a broadcast
`{"cmd":"discover","application":"Android",...}` on UDP 5480 with the device
name from `device.name`. Both listen on all interfaces, so they keep working
when the unit moves from the setup hotspot to the site WiFi.

At `/start` the controller asks the phone for the time (SNTP on UDP 1234,
then 123, 1 s each). If the clock is not NTP-synchronised it is set to the
phone's time (the service has `CAP_SYS_TIME` for this and nothing else).

Times are reported in `device.timezone` (default `Asia/Kolkata`, as the
AFS 5.0.3's +05:30); the zone database is built into the binary.

## Device API and WiFi setup

Port 5484, specified in "AFS Device API v1 — Specification". `internal/device`
holds the handlers and the contract tests (D-01 to D-14), `internal/unit`
binds them to the real unit, and `afs-mock` serves the same handlers over an
in-memory unit for the app team:

```
./bin/afs-mock -speed 10        # then: python3 tools/bench/devicecheck.py
```

The **label password** (`afsctl label`, created at install from the WiFi
adapter's MAC) is the password of the technician's phone hotspot `AFS-SETUP`
and the first device API password. The service keeps a NetworkManager
profile for that hotspot at low priority and one for the site WiFi at high
priority. A site WiFi set from the phone is joined with rollback: no IP in
60 s and the unit is back on the previous network with the reason recorded.
While the unit sits on the hotspot with a site profile saved, it looks for
the site WiFi every 30 s and rejoins it.

Login state lives in `/etc/afs/auth.json` (salt and derived key only).
`sudo afsctl reset-password` forgets it, so the label password works again.

## What the package sets up on the box

- systemd service as user `afs`, restart always, 30 s watchdog, `CAP_SYS_TIME`
  only, `/etc/afs` and `/var/lib/afs` the only writable paths
- polkit grants for user `afs`: NetworkManager and reboot
- udev: ModemManager kept off USB serial ports; `/dev/afs-rs485` for known chips
- journald persistent and capped (200 MB, 1 month)
- systemd hardware watchdog (`RuntimeWatchdogSec=30s`, `iTCO_wdt`)
- firewall (nftables): SSH, 5480/udp, 5482, 5484, ping, replies; the previous
  `/etc/nftables.conf` is kept as `/etc/nftables.conf.pre-afs`
- unattended security updates, never an automatic reboot
- time zone Asia/Kolkata
- an upgrade is refused while a delivery is in progress

`docs/GOLDEN_IMAGE.md` has the steps that are done once per image (SSH
key-only, kernel hold, netplan).

## Records

`/var/lib/afs/records/0001.rec` … `4095.rec`, one 4 KB file per delivery,
byte-for-byte the flash sector AFS 5.0.3 writes (header, log entries,
diagnostics page, result page, CRC-16/Modbus), so the apps read them
unchanged. `pointer.json` holds the last number and the rollover count.
Each log entry is on disk as soon as it happens. After a power cut the
unfinished record is closed with end reason POWER_LOSS and its header is used
to resume the delivery if the meter still has it open. More than 104 log
entries: the first 96 and the latest 8 are kept (AFS 5.0.3 overwrote the
first ones). Records are never deleted by the package.

## Bench test without a meter

```
./bin/vegasim -pty -auto 25        # prints e.g. /dev/pts/3; CMD44 delivers 25 L
# config: "rs485": {"port": "/dev/pts/3"}
```

The apps can then run start → deliver → stop → read against the box.

## RS-485 port selection

`rs485.port` is `"auto"` by default. The service lists USB serial adapters
(`/dev/ttyUSB*`, `/dev/ttyACM*`; built-in `ttyS*` UARTs are never used),
tries known RS-485 chips first (FTDI FT232R and WCH CH343, used on Waveshare
USB-RS485 converters, then CH340, CP210x, PL2303, then anything else), and
picks the one on which the meter answers a CMD30 status request. If the meter
does not answer (switched off, cable out) it keeps the best candidate and
retries every 10 seconds. A fixed path such as `/dev/serial/by-id/usb-FTDI_...`
can be set instead.

## Gate 0 checklist (on the box)

1. `sudo apt install ./afs-controller_0.4.1_amd64.deb`
2. `systemctl status afs-controller` shows `active (running)` and a status line
3. `afsctl ports` lists the Waveshare adapter: note its USB ID and chip
4. With the meter powered: the journal shows `meter found: meter answered on ...`
5. `sudo systemctl restart afs-controller`, then `journalctl -u afs-controller -n 20`
   shows `resetReason=SOFTWARE`
6. `sudo systemctl kill -s KILL afs-controller`: it restarts by itself within
   2 s and logs `resetReason=PANIC`
